var nombre = prompt("Ingrese el nombre")
var apellido = prompt("Ingrese el apellido")
alert("Bienvenido " + nombre + " " + apellido)