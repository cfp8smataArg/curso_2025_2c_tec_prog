//implementación externa
alert("Hola chicosssssss que tal?")