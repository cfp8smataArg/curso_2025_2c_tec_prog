function sumar(){
    var nro1 = parseFloat(document.getElementById("numero1").value)
    var nro2 = parseFloat(document.getElementById("numero2").value)
    var resultado = nro1 + nro2
    document.getElementById("resultado").value = resultado
}

function restar(){
    var nro1 = parseFloat(document.getElementById("numero1").value)
    var nro2 = parseFloat(document.getElementById("numero2").value)
    var resultado = nro1 - nro2
    document.getElementById("resultado").value = resultado
}

function multiplicar(){
    var nro1 = parseFloat(document.getElementById("numero1").value)
    var nro2 = parseFloat(document.getElementById("numero2").value)
    var resultado = nro1 * nro2
    document.getElementById("resultado").value = resultado
}

function dividir(){
    var nro1 = parseFloat(document.getElementById("numero1").value)
    var nro2 = parseFloat(document.getElementById("numero2").value)

    if(nro2 != 0){
        resultado = nro1/nro2
        document.getElementById("resultado").value = resultado
    }
    else{
        document.getElementById("resultado").value = "Error / 0!"
    }
}